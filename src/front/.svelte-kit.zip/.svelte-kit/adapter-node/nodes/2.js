

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DmE4vdZW.js","_app/immutable/chunks/DIX_2_Kn.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/BuIEBbwP.js","_app/immutable/chunks/DD7gBCXI.js"];
export const stylesheets = [];
export const fonts = [];
