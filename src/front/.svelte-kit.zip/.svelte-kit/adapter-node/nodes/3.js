

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/about/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.DruVbiIZ.js","_app/immutable/chunks/DIX_2_Kn.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/BuIEBbwP.js"];
export const stylesheets = [];
export const fonts = [];
