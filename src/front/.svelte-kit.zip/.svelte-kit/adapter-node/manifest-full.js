export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.CcfQaI0b.js",app:"_app/immutable/entry/app.UpEVq5iO.js",imports:["_app/immutable/entry/start.CcfQaI0b.js","_app/immutable/chunks/CeP-OJ62.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/DKK6kD1l.js","_app/immutable/chunks/K_c5ydUc.js","_app/immutable/entry/app.UpEVq5iO.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/DKAeOcQo.js","_app/immutable/chunks/DD7gBCXI.js","_app/immutable/chunks/DIX_2_Kn.js","_app/immutable/chunks/YMRWdC1s.js","_app/immutable/chunks/K_c5ydUc.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/about",
				pattern: /^\/about\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/accidents-stats",
				pattern: /^\/accidents-stats\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/registrations-stats",
				pattern: /^\/registrations-stats\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
