import { h as head, c as pop, p as push, e as ensure_array_like, f as attr } from "../../../chunks/index2.js";
import { T as Table, B as Button } from "../../../chunks/Theme.svelte_svelte_type_style_lang.js";
import { e as escape_html } from "../../../chunks/escaping.js";
function _page($$payload, $$props) {
  push();
  let VCH = [];
  let newAccidentId = "";
  let newYear = "";
  let newMonth = "";
  let newProvince = "";
  let newMunicipality_code = "";
  let newRoad = "";
  let newKm = "";
  let newDirection_1f = "";
  let newAccidentType = "";
  let newTotal_victims = "";
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>
        ACCIDENTS STATS
    </title>`;
  });
  $$payload.out += `<h2>Accidents Stats Table</h2> `;
  Table($$payload, {
    children: ($$payload2) => {
      const each_array = ensure_array_like(VCH);
      $$payload2.out += `<thead><tr><th>accident_id</th><th>year</th><th>month</th><th>province</th><th>municipality_code</th><th>road</th><th>km</th><th>direction_1f</th><th>accident_type</th><th>total_victims</th></tr></thead> <tbody><tr><td><input${attr("value", newAccidentId)}></td><td><input${attr("value", newYear)}></td><td><input${attr("value", newMonth)}></td><td><input${attr("value", newProvince)}></td><td><input${attr("value", newMunicipality_code)}></td><td><input${attr("value", newRoad)}></td><td><input${attr("value", newKm)}></td><td><input${attr("value", newDirection_1f)}></td><td><input${attr("value", newAccidentType)}></td><td><input${attr("value", newTotal_victims)}></td><td>`;
      Button($$payload2, {
        color: "secondary",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Create Accident`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----></td></tr><!--[-->`;
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let dato = each_array[$$index];
        $$payload2.out += `<tr><td>${escape_html(dato.accident_id)}</td><td>${escape_html(dato.year)}</td><td>${escape_html(dato.month)}</td><td>${escape_html(dato.province)}</td><td>${escape_html(dato.municipality_code)}</td><td>${escape_html(dato.road)}</td><td>${escape_html(dato.km)}</td><td>${escape_html(dato.direction_1f)}</td><td>${escape_html(dato.accident_type)}</td><td>${escape_html(dato.total_victims)}</td><td>`;
        Button($$payload2, {
          color: "warning",
          children: ($$payload3) => {
            $$payload3.out += `<!---->Edit`;
          },
          $$slots: { default: true }
        });
        $$payload2.out += `<!----> `;
        Button($$payload2, {
          color: "danger",
          children: ($$payload3) => {
            $$payload3.out += `<!---->Delete`;
          },
          $$slots: { default: true }
        });
        $$payload2.out += `<!----></td></tr>`;
      }
      $$payload2.out += `<!--]--></tbody>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!---->`;
  pop();
}
export {
  _page as default
};
