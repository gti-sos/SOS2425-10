

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.D0Y3l2Ya.js","_app/immutable/chunks/DIX_2_Kn.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/BuIEBbwP.js","_app/immutable/chunks/DKAeOcQo.js","_app/immutable/chunks/DD7gBCXI.js","_app/immutable/chunks/CxrqU8dc.js","_app/immutable/chunks/CeP-OJ62.js","_app/immutable/chunks/DKK6kD1l.js","_app/immutable/chunks/K_c5ydUc.js"];
export const stylesheets = [];
export const fonts = [];
