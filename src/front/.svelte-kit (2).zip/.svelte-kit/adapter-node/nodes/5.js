

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/registrations-stats/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.BAtxY49x.js","_app/immutable/chunks/DIX_2_Kn.js","_app/immutable/chunks/KdhVLU-_.js","_app/immutable/chunks/BuIEBbwP.js","_app/immutable/chunks/DKAeOcQo.js","_app/immutable/chunks/DD7gBCXI.js","_app/immutable/chunks/FxEMXmDF.js","_app/immutable/chunks/YMRWdC1s.js","_app/immutable/chunks/hoEyBp_8.js","_app/immutable/chunks/CxrqU8dc.js","_app/immutable/chunks/DKK6kD1l.js","_app/immutable/chunks/K_c5ydUc.js"];
export const stylesheets = ["_app/immutable/assets/Theme.C6eT-fc2.css"];
export const fonts = [];
