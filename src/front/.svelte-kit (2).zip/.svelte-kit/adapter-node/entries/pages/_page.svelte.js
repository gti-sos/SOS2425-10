import { h as head } from "../../chunks/index2.js";
function _page($$payload) {
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>
        DGT STATS
    </title>`;
  });
  $$payload.out += `<!---->Bienvenido a la página desarrollada por: VCH, IOM y JAM <p>API'S: <a href="/api/v1/accidents-stats">API accidents-stats</a> <a href="/api/v1/registrations-stats">API registrations-stats</a></p> <p>DOCS: <a href="/api/v1/accidents-stats/docs">DOCS accidents-stats</a> <a href="/api/v1/registrations-stats/docs">DOCS registrations-stats</a></p> <p>REPOSITORIO: <a href="https://github.com/gti-sos/SOS2425-10">GRUPO 10</a></p> <p>COMPONENTES DEL EQUIPO:</p><p><a href="https://github.com/viccabhur10">Víctor José Cabrera Hurtado</a> : accidents-stats</p> <p><a href="https://github.com/jesaznmon23">Jesús Aznar Montero</a> : registrations-stats</p> <p><a href="https://github.com/IgnacioOrtizMoreno">Ignacio Ortiz Moreno</a> : radars-stats</p>`;
}
export {
  _page as default
};
