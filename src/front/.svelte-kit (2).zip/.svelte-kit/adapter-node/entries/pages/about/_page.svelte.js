import { e as escape_html } from "../../../chunks/escaping.js";
import "clsx";
import { D as DEV } from "../../../chunks/false.js";
const dev = DEV;
function _page($$payload) {
  $$payload.out += `<!---->pagina de prueba (Development = ${escape_html(dev)})`;
}
export {
  _page as default
};
