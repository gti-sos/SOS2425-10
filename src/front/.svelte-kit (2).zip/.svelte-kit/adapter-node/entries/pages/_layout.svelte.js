import { d as slot } from "../../chunks/index2.js";
import "clsx";
function Footer($$payload) {
  $$payload.out += `<p><a href="/about">about</a></p>`;
}
function Header($$payload) {
  $$payload.out += `<h1>My APP</h1> <p><a href="/">Inicio</a> <a href="/about">About</a></p> <p>Estadísticas: <a href="/accidents-stats">accidents-stats</a> <a href="/registrations-stats">registrations-stats</a></p>`;
}
function _layout($$payload, $$props) {
  Header($$payload);
  $$payload.out += `<!----> <hr> <!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----> <hr> `;
  Footer($$payload);
  $$payload.out += `<!---->`;
}
export {
  _layout as default
};
