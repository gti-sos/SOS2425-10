import { h as head, c as pop, p as push, e as ensure_array_like, f as attr } from "../../../chunks/index2.js";
import { T as Table, B as Button } from "../../../chunks/Theme.svelte_svelte_type_style_lang.js";
import { e as escape_html } from "../../../chunks/escaping.js";
function _page($$payload, $$props) {
  push();
  let JAM = [];
  let newYear = "";
  let newProvince = "";
  let newTotal_general_national = "";
  let newTotal_general_import = "";
  let newTotal_general_auction = "";
  let newTotal_general = "";
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>
        REGISTRATIONS STATS
    </title>`;
  });
  $$payload.out += `<h2>Registrations Stats Table</h2> `;
  Table($$payload, {
    children: ($$payload2) => {
      const each_array = ensure_array_like(JAM);
      $$payload2.out += `<thead><tr><th>year</th><th>province</th><th>total_general_national</th><th>total_general_import</th><th>total_general_auction</th><th>total_general</th></tr></thead> <tbody><tr><td><input${attr("value", newYear)}></td><td><input${attr("value", newProvince)}></td><td><input${attr("value", newTotal_general_national)}></td><td><input${attr("value", newTotal_general_import)}></td><td><input${attr("value", newTotal_general_auction)}></td><td><input${attr("value", newTotal_general)}></td><td>`;
      Button($$payload2, {
        color: "secondary",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Create Registration`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----></td></tr><!--[-->`;
      for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
        let dato = each_array[$$index];
        $$payload2.out += `<tr><td>${escape_html(dato.year)}</td><td>${escape_html(dato.province)}</td><td>${escape_html(dato.total_general_national)}</td><td>${escape_html(dato.total_general_import)}</td><td>${escape_html(dato.total_general_auction)}</td><td>${escape_html(dato.total_general)}</td><td>`;
        Button($$payload2, {
          color: "danger",
          children: ($$payload3) => {
            $$payload3.out += `<!---->Delete`;
          },
          $$slots: { default: true }
        });
        $$payload2.out += `<!----></td></tr>`;
      }
      $$payload2.out += `<!--]--></tbody>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!---->`;
  pop();
}
export {
  _page as default
};
